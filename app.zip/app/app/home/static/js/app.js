

var app = new Vue({
  el:'main',
  delimiters:['[[', ']]'],
  data: {
    error : {
      title: "ERROR",
      body: "Unknown Error",
    },
    indicators: [],
    modifiedIndicators: {},
    suspect: {
      id: -1,
      name: "",
      links: "",
      score: 0,
      first_surv: "",
      second_surv: "",
    },
    suspectList : [],
    modal : {
      title : "",
      body : "",
    },
    csrf: "",
    suspectTable: null,
  },
  methods: {
    /* Helpers */
    updateSuspectTable: function() {
      if (this.suspectTable === null) {
        this.suspectTable = new DataTable("#suspect-table", {
          columns: [
            { title: 'Name' },
            { title: 'Probability' },
            { title: 'First Surv.' },
            { title: 'Second Surv.' },
            { title: 'Location' },
            { title: 'Delete' },
          ],
          data: this.suspectList
        });
      } else {
        this.suspectTable.clear();
        this.suspectTable.rows.add(this.suspectList);
        this.suspectTable.draw();
      }
      
    },
    sendGetRequest: async function(url, params) {
      let g_url = url;
      if (Object.keys(params).length > 0) {
        g_url += '?';
        for (let key in params) {
          g_url += key + '=' + params[key] + '&';
        }
        g_url = g_url.slice(0, g_url.length - 1);
      }
      let response = await fetch(g_url);
      let jsonResp = await response.json();
      
      return jsonResp;
    },
    sendPostRequest: async function(url, data) {
      const response = await fetch(url, {
        method: 'POST',
        mode: 'same-origin',
        cache: 'no-cache',
        credentials: 'same-origin',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'X-CSRFTOKEN': this.csrf,
        },
        origin: 'http://127.0.0.1',
        redirect: 'follow',
        body: JSON.stringify(data),
      });
      try {
        let jsonResp = await response.json();
        if (jsonResp["error"]) {
          this.error.title = "Error";
          this.error.body = jsonResp["reason"];
          return false;
        } else {
          return true;
        }
      } catch (err) {
        this.error.title = "Error Inesperado";
        this.error.body = err.message;
        return false;
      }
    },
    resetIndicators: function() {
      this.suspect = {
        id: -1,
        name: "",
        links: "",
        score: 0,
        first_surv: "",
        second_surv: "",
      };
      this.modifiedIndicators = {};
      let tags = document.getElementsByTagName("input");
      for (var i = 0; i < tags.length; ++i) {
        if (tags[i].getAttribute("type") === "hidden") {
          continue;
        }
        tags[i].value = "";
      }
      let plot = document.getElementById("suspect-location-map");
      plot.innerHTML = "";
    },
    updateModifiedIndicators: function() {
      let indicators = document.getElementsByClassName("indicator");
      for (var i = 0; i < indicators.length; ++i) {
        let indicatorId = indicators[i].children[2].children[1].value;
        let indicatorDate = indicators[i].children[1].children[0].value;
        let indicatorLocation = indicators[i].children[2].children[0].value;
        if (indicatorDate != "" || indicatorLocation != "") {
          this.modifiedIndicators[indicatorId] = {
            date: indicatorDate,
            loc: indicatorLocation
          };
        } else {
          delete this.modifiedIndicators[indicatorId];
        }
      }
    },
    reloadSuspect: function(el) {
      this.resetIndicators();
      this.suspect.name = el.text;
      this.suspect.links = "";
      this.apiGetSuspect();
    },
    showModal : function(title, body) {
      let m = document.getElementById("modal-default");
      m.classList.add("show");
      m.style.display = "block";
      this.modal.title = title;
      this.modal.body = body;
    },
    hideModal : function() {
      let m = document.getElementById("modal-default");
      m.classList.remove("show");
      m.style.display = "none";
    },
    /* API Functions */
    apiDeleteSuspect: async function(suspectName) {
      let url = "/api/suspect/delete";
      let params = {name: suspectName};
      let reqSuccess = await this.sendPostRequest(url, params);
      if (reqSuccess) {
        this.showModal("Success", "Successfully deleted suspect");
        this.apiListSuspects();
      }
    },
    apiListIndicators : async function() {
      let url = "/api/indicators/list";
      let params = {};

      let resp = await this.sendGetRequest(url, params);
      if (resp.error == false) {
        this.indicators = resp.indicators;
      }
    },
    apiComputeSuspect : async function() {
      let url = "/api/suspect/update";
      let params = {
        id : this.suspect.id,
        name : this.suspect.name,
        links : this.suspect.links,
        indicators : this.modifiedIndicators,
      };
      this.showModal("Loading...", "Please wait while the score is being computed");
      let requestSuccess = await this.sendPostRequest(url, params);
      this.hideModal();
      if (!requestSuccess) {}
      this.apiGetSuspect();
    },
    apiGetSuspect : async function() {
      let url = "/api/suspect/info";
      let params = {
        name : this.suspect.name,
      };
      let resp = await this.sendGetRequest(url, params);
      if (resp.error == false) {
        this.suspect = resp.suspect;
        document.getElementById("tabs-text-2-tab").click();
      }
    },
    apiListSuspects : async function() {
      let url = "/api/suspect/list";
      let params = {};
      let resp = await this.sendGetRequest(url, params);
      if (resp.error == false) {
        this.suspectList = resp.suspectList;
        this.updateSuspectTable();
      }
    },
    apiGetNetwork : async function() {
      let url = "/api/suspect/links"
      let params = {};
      let resp = await this.sendGetRequest(url, params);
      
      if (resp.error == false) {
        var chartDom = document.getElementById('network-chart');
        var myChart = echarts.init(chartDom);
        var option;
        
        option = {
          title: {
            text: 'Suspect Network',
            top: 'bottom',
            left: 'right',
          },
          tooltip: {},
          legend: [{data: resp.nodes.map(function(a) {return a.name;})}],
          animationDurationUpdate: 1500,
          animationEasingUpdate: 'quinticInOut',
          series:[
            {
              name: 'Suspect Network',
              type: 'graph',
              layout: 'circular',
              circular: {rotateLabel: true},
              data: resp.nodes,
              links: resp.edges,
              categories: resp.nodes.map(function(a) {return {name: a.name};}),
              roam: true,
              label: {
                position: 'right',
                formatter: '{b}'
              },
              lineStyle: {
                color: 'source',
                curveness: 0.3
              },
              emphasis: {
                focus: 'adjacency',
                lineStyle: {
                  width: 10
                }
              }
            }
          ],
        };
        myChart.setOption(option);
      }
    },
    apiGetLocationMap: async function() {
      let url = '/api/suspect/location';
      let params = {'name':this.suspect.name};
      let resp = await this.sendGetRequest(url, params);
      if (resp.error == false) {
        let plot = document.getElementById("suspect-location-map");
        plot.innerHTML = "";
        var scr = document.createElement("script");
        scr.text = resp.script;
        //eval(scr.text);
        var div = document.createElement("div");
        div.innerHTML = resp.div;
        plot.appendChild(div);
        plot.appendChild(scr);
      } else {
        this.showModal("ERROR", resp.reason);
      }
    },

  },
});
