from django.http import JsonResponse

def api_error(reason):
    """
    Returns the error response
    """
    resp = {
        'error': True,
        'reason': reason
    }
    return JsonResponse(resp)

def api_success(reason):
    """
    Returns the success response
    """
    resp = {
        'error': False,
        'reason': reason
    }
    return JsonResponse(resp)

# Error messages
INVALID_METHOD = 'Invalid method'
INVALID_SUSPECT = 'Invalid suspect'
SUSPECT_UPDATE_OK = 'Suspect update done'
