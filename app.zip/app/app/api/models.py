from django.db import models

class Suspect(models.Model):
    """
    Class that describes a suspect
    """
    name        = models.TextField()
    first_surv  = models.DateField(null=True)
    second_surv = models.DateField(null=True)
    location    = models.TextField(null=True)
    latitude    = models.FloatField(default=0)
    longitude   = models.FloatField(default=0)
    score       = models.FloatField(null=True)
    def __str__(self):
        return self.name

class SuspectLink(models.Model):
    """
    Stores links betwees suspects
    """
    origin = models.ForeignKey(Suspect, related_name="origin", on_delete=models.CASCADE)
    destin = models.ForeignKey(Suspect, related_name="destin", on_delete=models.CASCADE)
    is_direct = models.BooleanField(default=True)

class Indicator(models.Model):
    """
    The indicators, as defined in the document
    """
    name      = models.TextField()
    weight    = models.IntegerField()
    frequency = models.IntegerField()
    def __str__(self):
        return self.name

class SuspectIndicator(models.Model):
    """
    Indicators per suspect
    """
    indicator = models.ForeignKey(Indicator, on_delete=models.CASCADE)
    suspect = models.ForeignKey(Suspect, on_delete=models.CASCADE)
    date = models.DateField()
    location = models.TextField()
