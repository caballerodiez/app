import json
import datetime
import numpy as np
from geopy.geocoders import Nominatim
from geopy.exc import GeocoderTimedOut

import xyzservices.providers as xyz
from bokeh.plotting import figure, show
from bokeh.tile_providers import get_provider
from bokeh.embed import components
from bokeh.models import TapTool, WheelZoomTool, HoverTool
from bokeh.models import ColumnDataSource

from dateutil.relativedelta import relativedelta

from django.http import JsonResponse
from django.db.models import Q
from django.shortcuts import render
from django.utils import timezone

from .models import (
    Indicator,
    Suspect,
    SuspectIndicator,
    SuspectLink,
)

from .error import (
    api_error,
    api_success,
    INVALID_METHOD,
    INVALID_SUSPECT,
    SUSPECT_UPDATE_OK,
)

FIRST_SURVEILLANCE_INDICATORS = set([
    'Criminal suspect',
    'Contacting authorities about their intentions',
    'Engaging in conspiracy',
    'Contact with homeland terrorist',
    'Direction of a cell',
    'Confessing cellmates about intentions',
    'Confessing terror charges from another state',
    'Travelling to war zone or region with insurrectional activity',
    'Radical statements made public',
    'Considered as a threat',
    'Specific foreign intelligence warnings',
    'Membership of radical group',
    'Sentences for terrorism',
    'Terrorism recruitment or training for foreign conflict',
    'Adopting salafist behaviours',
    'Contact with foreign terrorist',
    'Participation in jihadist insurgency abroad',
    'Relative contacting authorities about their intentions',
    'Threatening institutions',
    'Dissemination of radical propaganda',
    'Search of radical websites',
    'Criminal links'
])

# Create your views here.
def add_suspect_link(suspect1, suspect2, is_direct):
    if suspect1 == suspect2:
        return
    if suspect1.name < suspect2.name:
        SuspectLink.objects.create(
            origin=suspect1,
            destin=suspect2,
            is_direct=is_direct
        )
    else:
        SuspectLink.objects.create(
            origin=suspect2,
            destin=suspect1,
            is_direct=is_direct
        )



def wgs84_to_web_mercator(lon, lat):
    coords = [lon, lat]
    k = 6378137
    coords[0] = coords[0] * (k * np.pi/180.0)
    coords[1] = np.log(np.tan((90 + coords[1]) * np.pi/360.0)) * k
    return coords

def is_indicator_in_DB(indicator, db_indicators):
    for dbi in db_indicators:
        if indicator['name'] == dbi.name:
            return True
    return False

def IndicatorList(request):
    if request.method != 'GET':
        return api_error(INVALID_METHOD)
    indicators = Indicator.objects.all()
    json_indicators = map(lambda x: {
        "id" : x.id,
        "name" : x.name,
    }, indicators)

    json_resp = {
        "error": False,
        "indicators" : list(json_indicators)
    }
    return JsonResponse(json_resp)

def ComputeSuspectProbability(request):
    if request.method != 'POST':
        return api_error(INVALID_METHOD)

    suspect_info = json.loads(request.body)


    # Try to retrieve by name
    suspect = Suspect.objects.filter(name=suspect_info['name'].strip()).first()
    # Add suspect to the database
    if suspect is None:
        suspect = Suspect.objects.create(
            name = suspect_info['name'].strip(),
        )
    # Add links to the database
    try:
        links = [x.strip() for x in suspect_info['links'].split(',')]
    except KeyError:
        links = []

    for link in links:
        if link == "":
            continue
        to_suspect = Suspect.objects.filter(name=link).first()
        if to_suspect is None:
            to_suspect = Suspect.objects.create(name=link)
        # Suspect links are always alphabetical, origin -> destin
        suspect_link = SuspectLink.objects.filter((Q(origin=suspect) & Q(destin=to_suspect)) | (Q(origin=to_suspect) & Q(destin=suspect))).first()
        if suspect_link is None:
            add_suspect_link(suspect, to_suspect, True)
        elif suspect_link.is_direct == False:
            add_suspect_link(suspect, to_suspect, True)
            
    # Build indirect links
    for j in range(len(links)-1):
        if links[j] == "":
            continue
        suspect1 = Suspect.objects.filter(name=links[j]).first()
        suspect2 = Suspect.objects.filter(name=links[j+1]).first()
        if suspect2 is None:
            continue
        if suspect2.name == suspect1.name:
            continue

        indirect_link = SuspectLink.objects.filter(
            (Q(origin=suspect1) & Q(destin=suspect2)) | (Q(origin=suspect2) & Q(destin=suspect1))).first()
        if indirect_link is None:
            add_suspect_link(suspect1, suspect2, False)
    # Add indirect links for suspects already in db
    for link in links:
        suspect2 = Suspect.objects.filter(name=link).first()
        suspect_links = list(SuspectLink.objects\
                .filter((Q(origin=suspect2) | Q(destin=suspect2)) & Q(is_direct=True)).all())
        suspect_links.extend(list(SuspectLink.objects\
                .filter((Q(origin=suspect) | Q(destin=suspect)) & Q(is_direct=True)).all()))
        # Check all direct links for the suspect and attempt to add indirect links
        for sl in suspect_links:
            if sl.origin == suspect and sl.destin == suspect2:
                continue
            if sl.origin == suspect2 and sl.destin == suspect:
                continue
            # Now that we know that this link is not between suspect and suspect2
            # check if there is already a link between the current link suspect
            # and the other suspect of the link (the one that is not "suspect")
            if sl.origin == suspect:
                linko = SuspectLink.objects.filter((Q(origin=suspect2) & Q(destin=sl.destin)) | (Q(origin=sl.destin) & Q(destin=suspect2))).first()
                if linko is None:
                    add_suspect_link(sl.destin, suspect2, False)
            else:
                linko = SuspectLink.objects.filter((Q(origin=suspect2) & Q(destin=sl.origin)) | (Q(origin=sl.origin) & Q(destin=suspect2))).first()
                if linko is None:
                    add_suspect_link(sl.origin, suspect2, False)
            if sl.origin == suspect2:
                linko = SuspectLink.objects.filter((Q(origin=suspect) & Q(destin=sl.destin)) | (Q(origin=sl.destin) & Q(destin=suspect))).first()
                if linko is None:
                    add_suspect_link(sl.destin, suspect, False)
            else:
                linko = SuspectLink.objects.filter((Q(origin=suspect) & Q(destin=sl.origin)) | (Q(origin=sl.origin) & Q(destin=suspect))).first()
                if linko is None:
                    add_suspect_link(sl.origin, suspect, False)


    # Add indicators to the database
    for ind_id, ind in suspect_info['indicators'].items():
        indicator = Indicator.objects.filter(id=ind_id).first()
        db_ind = SuspectIndicator.objects.create(
            suspect = suspect,
            indicator = indicator,
            date = ind['date'],
            location = ind['loc'],
        )
    score = 0
    total_frequency = 0

    indicators = SuspectIndicator.objects.filter(suspect=suspect).all()
    first_surveillance = timezone.now().date()
    location = ""
    most_recent = datetime.datetime(year=1900,month=1,day=1).date()
    add_surveillance = False
    for sus_indicator in indicators:
        if sus_indicator.date > most_recent:
            if sus_indicator.location:
                location = sus_indicator.location
                most_recent = sus_indicator.date
        if sus_indicator.indicator.name in FIRST_SURVEILLANCE_INDICATORS:
            first_surveillance = min(sus_indicator.date, first_surveillance)
            add_surveillance = True
        score += sus_indicator.indicator.weight / 100 * sus_indicator.indicator.frequency
        total_frequency += sus_indicator.indicator.frequency
    if total_frequency > 0:
        score /= total_frequency
    else:
        score = 0
    suspect.score = round(score * 100, 2)
    if location:
        latest_indicator = SuspectIndicator.objects.filter(~Q(location="")).order_by('-date').first()
        if latest_indicator.date <= most_recent or latest_indicator is None:
            try:
                geolocator = Nominatim(user_agent="LocationAppv1.0")
                geolocation = geolocator.geocode(location)
                if geolocation is not None:
                    suspect.location = location
                    suspect.longitude, suspect.latitude = wgs84_to_web_mercator(geolocation.longitude,geolocation.latitude)
            except GeocoderTimedOut:
                return api_error("Geocoder timed out. Suspect has not been saved. Please try again later")
    if add_surveillance:
        suspect.first_surv = first_surveillance
        suspect.second_surv = first_surveillance + relativedelta(months=15)
    suspect.save()

    return api_success(SUSPECT_UPDATE_OK)

def GetSuspectByName(request):
    if request.method != "GET":
        return api_error(INVALID_METHOD)
    name = request.GET.get("name")
    if name is None:
        return api_error("Missing suspect name")
    suspect = Suspect.objects.filter(name=name).first()
    if suspect is None:
        return api_error("Suspect is not in the database")

    if suspect.first_surv is not None:
        json_suspect = {
            "id": suspect.id,
            "name": suspect.name,
            "score": suspect.score,
            "location": suspect.location,
            "first_surv": suspect.first_surv.year,
            "second_surv": suspect.second_surv.year,
        }
    else:
        json_suspect = {
            "id": suspect.id,
            "name": suspect.name,
            "score": suspect.score,
            "location": suspect.location,
            "first_surv": "-",
            "second_surv": "-",
        }
    json_resp = {
        "error": False,
        "suspect": json_suspect,
    }
    return JsonResponse(json_resp)

def SuspectList(request):
    if request.method != "GET":
        return api_error(INVALID_METHOD)

    suspects = Suspect.objects.all()

    json_suspects = []
    for x in suspects:
        if x.first_surv is None:
            json_suspects.append([
                f'<a href="#" onclick="app.reloadSuspect(this)">{x.name}</a>',
                x.score,
                '-',
                '-',
                x.location,
                f'<button type="button" class="btn btn-icon-only btn-danger" onclick="app.apiDeleteSuspect(\'{x.name}\')"><span class="fas fa-times"></span></button>'])
        else:
            json_suspects.append([
                f'<a href="#" onclick="app.reloadSuspect(this)">{x.name}</a>',
                x.score,
                f'{x.first_surv.year}-{str(x.first_surv.month).zfill(2)}',
                f'{x.second_surv.year}-{str(x.second_surv.month).zfill(2)}',
                x.location,
                f'<button type="button" class="btn btn-icon-only btn-danger" onclick="app.apiDeleteSuspect(\'{x.name}\')"><span class="fas fa-times"></span></button>'])

    json_resp = {
        "error": False,
        "suspectList": json_suspects,
    }
    return JsonResponse(json_resp)

def DeleteSuspect(request):
    if request.method != "POST":
        return api_error(INVALID_METHOD)
    suspect = json.loads(request.body)
    db_suspect = Suspect.objects.filter(name= suspect['name']).first()

    db_suspect.delete()

    return api_success("Successfully deleted suspect")


def GetNetwork(request):
    if request.method != "GET":
        return api_error(INVALID_METHOD)
    links = SuspectLink.objects.all()
    suspects = Suspect.objects.all()
    nodes = []
    node_idx = {}
    for i, s in enumerate(suspects):
        node = {
            "id": i,
            "name": s.name,
            "symbolSize": 10,
            "value": s.score,
            "category": s.name,
            "label":{"show": True}
        }
        node_idx[s.name] = i
        nodes.append(node)

    edges = []
    for lnk in links:
        source = node_idx[lnk.origin.name]
        target = node_idx[lnk.destin.name]
        if lnk.is_direct:
            nodes[source]["symbolSize"] += 10
            nodes[target]["symbolSize"] += 10
            edges.append({
                "target": target,
                "source": source,
                "lineStyle":{
                    "type":"solid",
                    "color": "rgb(0, 0, 0)",
                }
            })
        else:
            edges.append({
                "target": target,
                "source": source,
                "lineStyle":{
                    "type":"dashed",
                    "color": "rgb(0, 0, 0)",
                }
            })

    json_resp = {
        "error": False,
        "nodes": nodes,
        "edges": edges,
    }
    return JsonResponse(json_resp)

def clean_script(scr):
    return scr.replace('<script type="text/javascript">','').replace('</script>','')

def GetSuspectLocation(request):
    if request.method != "GET":
        return api_error(INVALID_METHOD)
    suspect_name = request.GET.get('name')
    if suspect_name is None:
        return api_error(INVALID_SUSPECT)

    suspect = Suspect.objects.filter(name=suspect_name).first()

    if suspect is None:
        return api_error(INVALID_SUSPECT)

    HEIGHT = 600
    WIDTH  = 900

    tile_provider = get_provider(xyz.OpenStreetMap.Mapnik)

    TOOLTIPS = [
        ("ID", "@name"),
        ("x", "@x"),
        ("y", "@y"),
    ]
    #p = figure(x_range=(-6.560e5,-6.460e5), y_range=(5.362e6, 5.374e6),
    p = figure(x_range=(suspect.longitude - 0.1e5,suspect.longitude + 0.1e5),
               y_range=(suspect.latitude - 0.05e6, suspect.latitude + 0.05e6),
               height=HEIGHT, width=WIDTH, tooltips=TOOLTIPS, active_scroll="wheel_zoom",
               x_axis_type="mercator", y_axis_type="mercator")
    p.grid.visible = False
    p.add_tile(tile_provider)
    p.circle(
        x='x',
        y='y',
        radius=15000,
        alpha=0.5,
        color="red",
        source=ColumnDataSource(data=dict(
            x=[suspect.longitude],
            y=[suspect.latitude],
            name=[suspect.name],
        )),
    )
    script, div = components(p)
    json_resp = {
        'error': False,
        'script': clean_script(script),
        'div':div
    }
    return JsonResponse(json_resp)
