from django.contrib import admin

from .models import (
    Indicator,
    Suspect,
    SuspectIndicator,
    SuspectLink,
)

# Register your models here.
admin.site.register(Indicator)
admin.site.register(Suspect)
admin.site.register(SuspectIndicator)
admin.site.register(SuspectLink)
