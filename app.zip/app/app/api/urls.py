
from django.urls import path

from . import (
    views,
)

app_name = 'api'

urlpatterns = [
    path('indicators/list', views.IndicatorList),
    path('suspect/update', views.ComputeSuspectProbability),
    path('suspect/info', views.GetSuspectByName),
    path('suspect/list', views.SuspectList),
    path('suspect/delete', views.DeleteSuspect),
    path('suspect/links', views.GetNetwork),
    path('suspect/location', views.GetSuspectLocation),
]
